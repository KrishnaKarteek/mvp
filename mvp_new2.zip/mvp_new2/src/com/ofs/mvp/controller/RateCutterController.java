package com.ofs.mvp.controller;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.ofs.mvp.model.Rate_Cutter;
import com.ofs.mvp.service.RateCutterService;
import com.ofs.mvp.service.RateCutterServiceImpl;

@Path("/rate_cutter")
public class RateCutterController {
	
	RateCutterService rateCutterService = new RateCutterServiceImpl();
	
	@Path("/get_rate_cutter")
	@GET
	@Produces("application/json")
	public List<Rate_Cutter> getRateDetails() throws Exception
	{
		return rateCutterService.getRateDetails();
	}

}

package com.ofs.mvp.controller;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.ofs.mvp.service.ForgotPasswordService;
import com.ofs.mvp.service.ForgotPasswordServiceImpl;

@Path("/forgot_pwd")
public class ForgotPasswordController {

	ForgotPasswordService forgotPasswordService = new ForgotPasswordServiceImpl();

	@Path("/get_forgot_pwd")
	@GET
	@Produces("application/json")
	public String getPassword(@QueryParam("email") String email) throws Exception
	{
		return forgotPasswordService.getPassword(email);
	}


}

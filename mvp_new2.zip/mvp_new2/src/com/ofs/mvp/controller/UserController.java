package com.ofs.mvp.controller;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import org.codehaus.jettison.json.JSONObject;

import java.util.List;

import com.ofs.email_notification.EmailNotification;
import com.ofs.mvp.cryptography.*;
import com.ofs.mvp.model.Bill_Details;
import com.ofs.mvp.model.Feedback;

import com.ofs.mvp.model.Rate_Cutter;
import com.ofs.mvp.model.User;
import com.ofs.mvp.service.UserService;
import com.ofs.mvp.service.UserServiceImpl;


import javax.mail.internet.MimeMessage;

@Path("/user")
public class UserController  {
	
	UserService userService = new UserServiceImpl();
	
	//for sign in
	@Path("/auth")
	@GET
	@Produces("application/json")
	public User authUserByEmail(
			@QueryParam("email") String email,
			@QueryParam("pwd") String pwd			
			) throws Exception
	{

		String response="";
		JSONObject jsonObject = new JSONObject();

		TrippleDes td= new TrippleDes();
		String pwd2 = td.encrypt(pwd);
		
		User user = userService.findUserByEmail(email); 
		User userDup = null;
		 
		if(email.equalsIgnoreCase(user.getEmail()) && pwd2.equalsIgnoreCase(user.getPwd())) {
			userDup = user;
		} else{
			jsonObject.put("Status","Failure");			
			response = jsonObject.toString();	
		}
		return userDup;
	}
	
	//  for sign up 
	@Path("/add")
	@POST
	@Consumes("text/html")
	@Produces("text/html")
	public String addUser(
	
			@QueryParam("first_name") String first_name,
			@QueryParam("last_name") String last_name,
			@QueryParam("usr_name") String usr_name,
			@QueryParam("occupation") String occupation,
			@QueryParam("marital_status") String marital_status,
			@QueryParam("phone") long phone,
			@QueryParam("adress") String adress,
			@QueryParam("email") String email,
			@QueryParam("pwd") String pwd
			
			) throws Exception
	{
		TrippleDes td= new TrippleDes();
		
			User user = new User();
			user.setFirst_name(first_name);
			user.setLast_name(last_name);
			user.setUsr_name(usr_name);
			user.setOccupation(occupation);
			user.setMarital_status(marital_status);
			user.setEmail(email);
			user.setPhone(phone);
			user.setAdress(adress);

			String pwd2 = td.encrypt(pwd);
			
			user.setPwd(pwd2);
			user.setIs_active(1);
			
			return userService.addUser(user);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// Update User
	@Path("/update")
	@POST
	@Consumes("text/html")
	@Produces("text/html")
	public String updateUser(
	
			@QueryParam("first_name") String first_name,
			@QueryParam("last_name") String last_name,
			@QueryParam("usr_name") String usr_name,
			@QueryParam("occupation") String occupation,
			@QueryParam("marital_status") String marital_status,
			@QueryParam("phone") long phone,
			@QueryParam("adress") String adress,
			@QueryParam("email") String email,
			@QueryParam("service_no") int service_no
			) throws Exception
	{
			
		return userService.updateUser(first_name, last_name, usr_name, occupation, marital_status, phone, adress, email, service_no );
			
			
	}
	
	
	
	
		
		
	
	
}
	
	


package com.ofs.mvp.controller;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.ofs.mvp.model.Bill_Details;
import com.ofs.mvp.service.BillHistoryService;
import com.ofs.mvp.service.BillHistoryServiceImpl;

@Path("/bill_history")
public class BillHistoryController {
	
	BillHistoryService billHistoryService = new BillHistoryServiceImpl();
	
	// for getting bill history
		@Path("/get_bill_history")
		@GET
		@Produces("application/json")
		public List<Bill_Details> getBillHistory(
				@QueryParam("service_no") int service_no
				) throws Exception
		{
			List<Bill_Details> bill_details = (List<Bill_Details>) billHistoryService.getBillHistory( service_no );
				
			return bill_details;
		}
		

}

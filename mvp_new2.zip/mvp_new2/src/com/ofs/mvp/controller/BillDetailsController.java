package com.ofs.mvp.controller;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.ofs.mvp.model.Bill_Details;
import com.ofs.mvp.service.BillDetailsService;
import com.ofs.mvp.service.BillDetailsServiceImpl;


@Path("/bill_details")
public class BillDetailsController {
	
		BillDetailsService billDetailsService = new BillDetailsServiceImpl();
	
	//for getting bill details
		@Path("/get_bill_details")
		@GET
		@Produces("application/json")
		public Bill_Details getDetailsByServiceNo(
											@QueryParam("service_no") int service_no,
											@QueryParam("month") String month	,
											@QueryParam("year") String year	
											) throws Exception
		{
			
			Bill_Details bill_details = billDetailsService.findBillDetailsByServiceNo( service_no, month, year );
			
			return bill_details;
		}
	
	
		// for bill payment
		@Path("/bill_payment")
		@GET
		@Produces("application/json")
		public Bill_Details getPayment(
											@QueryParam("service_no") int service_no,
											@QueryParam("month") String month,
											@QueryParam("year") String year
											) throws Exception
		{
			
			Bill_Details bill_details = billDetailsService.getPaymentDetailsUpdate( service_no, month, year );	
			return bill_details;
			
		}
		
		// for getting payment details
		@Path("/payment_details")
		@GET
		@Produces("application/json")
		public Bill_Details getPaymentDetails(
				@QueryParam("bill_id") int bill_id
				) throws Exception
		{
			Bill_Details bill_details = (Bill_Details) billDetailsService.getPaymentDetails( bill_id );
			
			return bill_details;	
		}
		
		

}

package com.ofs.mvp.controller;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.ofs.mvp.service.EmailNotificationService;
import com.ofs.mvp.service.EmailNotificationServiceImpl;

@Path("/email_notification")
public class EmailNotificationController {
	
		EmailNotificationService emailNotificationService = new EmailNotificationServiceImpl();
	
	//for email notification
		@Path("/get_email_notification")
		@POST
		@Produces("application/json")
		public void getEmailNotification(@QueryParam("email") String email) throws Exception
		{
			emailNotificationService.getEmailNotification(email);
		}
		

}

package com.ofs.mvp.controller;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.ofs.mvp.model.Feedback;
import com.ofs.mvp.service.FeedbackService;
import com.ofs.mvp.service.FeedbackServiceImpl;

@Path("/feedback")
public class FeedbackController {
	
	
	FeedbackService feedbackService = new FeedbackServiceImpl();
	
		// Feedback
			@Path("/give_feedback")
			@POST
			@Consumes("text/html")
			@Produces("text/html")
			public String updateUser(
			
					@QueryParam("feedback_content") String feedback_content,
					@QueryParam("service_no") int service_no
					) throws Exception
			{
					
				Feedback feedback = new Feedback();
				
				feedback.setFeedback_content( feedback_content );
				feedback.setUser_id( service_no );
				
				return feedbackService.saveFeedback( feedback );
					
					
			}

}

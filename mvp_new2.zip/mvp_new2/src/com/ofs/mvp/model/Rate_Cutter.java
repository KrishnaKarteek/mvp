package com.ofs.mvp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="rate_tbl")
public class Rate_Cutter {
	
	@Id
	@GeneratedValue
	@Column(name="rate_id")
	private int rate_id;
	
	@Column(name="from_unit")
	private int from_unit;
	
	@Column(name="to_unit")
	private int to_unit;
	
	@Column(name="rate")
	private int rate;
	
	public int getRate_id() {
		return rate_id;
	}

	public void setRate_id(int rate_id) {
		this.rate_id = rate_id;
	}

	@Column(name="max_unit")
	private int max_unit;
	
	public int getFrom_unit() {
		return from_unit;
	}

	public void setFrom_unit(int from_unit) {
		this.from_unit = from_unit;
	}

	public int getTo_unit() {
		return to_unit;
	}

	public void setTo_unit(int to_unit) {
		this.to_unit = to_unit;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public int getMax_unit() {
		return max_unit;
	}

	public void setMax_unit(int max_unit) {
		this.max_unit = max_unit;
	}

	
	
	

}

package com.ofs.mvp.model;


import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.Table;


@Entity
@Table(name="bill_details_tbl")
public class Bill_Details {
	
	@Id
	@GeneratedValue
	@Column(name="bill_id")
	private int bill_id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="power_consumed")
	private float power_consumed;
	
	@Column(name="price_per_unit")
	private float price_per_unit;
	
	@Column(name="total_price")
	private float total_price;
	
	@Column(name="bill_date")
	private String bill_date;
	
	@Column(name="last_date")
	private String last_date;
	
	@Column(name="service_no")
	private int service_no;
	
	@Column(name="month")
	private String month;
	
	@Column(name="year")
	private String year;
	
	@Column(name="pay")
	private String pay;
	
	public int getBill_id() {
		return bill_id;
	}

	public void setBill_id(int bill_id) {
		this.bill_id = bill_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPower_consumed() {
		return power_consumed;
	}

	public void setPower_consumed(float power_consumed) {
		this.power_consumed = power_consumed;
	}

	public float getPrice_per_unit() {
		return price_per_unit;
	}

	public void setPrice_per_unit(float price_per_unit) {
		this.price_per_unit = price_per_unit;
	}

	public float getTotal_price() {
		return total_price;
	}

	public void setTotal_price(float total_price) {
		this.total_price = total_price;
	}

	public String getBill_date() {
		return bill_date;
	}

	public void setBill_date(String bill_date) {
		this.bill_date = bill_date;
	}

	public String getLast_date() {
		return last_date;
	}

	public void setLast_date(String last_date) {
		this.last_date = last_date;
	}

	public int getService_no() {
		return service_no;
	}

	public void setService_no(int service_no) {
		this.service_no = service_no;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getPay() {
		return pay;
	}

	public void setPay(String pay) {
		this.pay = pay;
	}
	
}

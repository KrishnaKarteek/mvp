package com.ofs.mvp.dao;

import java.util.List;



import java.util.Properties;

import javax.mail.Session;


import javax.mail.internet.MimeMessage;

import com.ofs.email_notification.EmailNotification;
import com.ofs.mvp.cryptography.*;
import com.ofs.mvp.model.Bill_Details;
import com.ofs.mvp.model.Feedback;
import com.ofs.mvp.model.Payment;
import com.ofs.mvp.model.Rate_Cutter;
import com.ofs.mvp.model.User;
import com.ofs.mvp.util.HibernateUtil;



public class UserDaoImpl implements UserDao{
	
	HibernateUtil hibernateUtil = new HibernateUtil();

	@Override
	public User findUserByEmail(String email) {
		hibernateUtil.openCurrentSession();
		
		User user =(User) hibernateUtil.getCurrentSession().createQuery("from User where email='"+email+"' and is_active=1").uniqueResult();
		
		hibernateUtil.closeCurrentSession();
		
		return user;
	}

	@Override
	public String addUser(User user) {
		hibernateUtil.openCurrentSessionwithTransaction();
		Integer id = (Integer)hibernateUtil.getCurrentSession().save(user);
		hibernateUtil.closeCurrentSessionwithTransaction();
		return "User record saved successfully with id:"+id;
	}

	

	

	

	/*@Override
	public String addPayment(Payment payment) {
		hibernateUtil.openCurrentSessionwithTransaction();
		Integer payment_id = (Integer)hibernateUtil.getCurrentSession().save(payment);
		hibernateUtil.closeCurrentSessionwithTransaction();
		return "User record saved successfully with id:"+payment_id;
	}*/

	

	
	

	

	@Override
	public String updateUser(String first_name, String last_name, String usr_name, String occupation,
			String marital_status, long phone, String adress, String email, int service_no) {
		
		hibernateUtil.openCurrentSessionwithTransaction();
		
		
		hibernateUtil.getCurrentSession().createQuery("UPDATE User SET first_name ='"+first_name+"', last_name='"+last_name+"', usr_name='"+usr_name+"', occupation='"+occupation+"', marital_status='"+marital_status+"', phone="+phone+", adress='"+adress+"', email='"+email+"'  where service_no="+service_no).executeUpdate();
		
		hibernateUtil.closeCurrentSessionwithTransaction();
		
		return "Succeccfull";
	}
	
	
	
	

	
}

package com.ofs.mvp.dao;

import com.ofs.mvp.model.Feedback;

public interface FeedbackDao {
	
	public String saveFeedback(Feedback feedback);

}

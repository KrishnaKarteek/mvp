package com.ofs.mvp.dao;

import java.util.List;

import com.ofs.mvp.model.Rate_Cutter;
import com.ofs.mvp.util.HibernateUtil;

public class RateCutterDaoImpl implements RateCutterDao {
	
	HibernateUtil hibernateUtil = new HibernateUtil();
	
	@Override
	public List<Rate_Cutter> getRateDetails() {
		
		hibernateUtil.openCurrentSession();
		
		List<Rate_Cutter> rate_cutter = (List<Rate_Cutter>) hibernateUtil.getCurrentSession().createQuery("from Rate_Cutter").list();
		
		hibernateUtil.closeCurrentSession();
		
		return rate_cutter;
	}

}

package com.ofs.mvp.dao;

import java.util.List;

import com.ofs.mvp.model.Bill_Details;

public interface BillHistoryDao {
	
	public List<Bill_Details> getBillHistory(int service_no);

}

package com.ofs.mvp.dao;

import com.ofs.mvp.model.Feedback;
import com.ofs.mvp.util.HibernateUtil;

public class FeedbackDaoImpl implements FeedbackDao {
	
	HibernateUtil hibernateUtil = new HibernateUtil();
	
	@Override
	public String saveFeedback(Feedback feedback) {
		hibernateUtil.openCurrentSessionwithTransaction();
		hibernateUtil.getCurrentSession().save(feedback);
		hibernateUtil.closeCurrentSessionwithTransaction();
		return "Successfull";
	}

}

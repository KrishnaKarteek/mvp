package com.ofs.mvp.dao;

import com.ofs.mvp.model.Bill_Details;

public interface BillDetailsDao {
	
	public Bill_Details findBillDetailsByServiceNo(int service_no, String month, String year);
	
	public Bill_Details getPaymentDetailsUpdate(int service_no, String month, String year);
	
	public Bill_Details getPaymentDetails(int bill_id);

}

package com.ofs.mvp.dao;

import java.util.List;

import com.ofs.mvp.model.Bill_Details;
import com.ofs.mvp.util.HibernateUtil;

public class BillHistoryDaoImpl implements BillHistoryDao {
	
	HibernateUtil hibernateUtil = new HibernateUtil();
	
	@Override
	public List<Bill_Details> getBillHistory(int service_no) {
		
		hibernateUtil.openCurrentSession();
		
		List<Bill_Details> bill_details = (List<Bill_Details>) hibernateUtil.getCurrentSession().createQuery("from Bill_Details where service_no="+service_no).list();
		
		hibernateUtil.closeCurrentSession();
		
		return bill_details;
	}

}

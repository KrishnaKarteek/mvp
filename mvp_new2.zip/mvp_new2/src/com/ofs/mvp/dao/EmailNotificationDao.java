package com.ofs.mvp.dao;

public interface EmailNotificationDao {
	
	public void getEmailNotification(String email);

}

package com.ofs.mvp.dao;

import java.util.Properties;

import javax.mail.Session;

import com.ofs.email_notification.EmailNotification;
import com.ofs.mvp.cryptography.TrippleDes;
import com.ofs.mvp.model.User;


public class ForgotPasswordDaoImpl implements ForgotPasswordDao{
	
	
	@Override
	public String getPassword(String email) {
		
		UserDaoImpl userDaoImpl = new UserDaoImpl();
		
		User user = userDaoImpl.findUserByEmail( email );
		
	    String smtpHostServer = "mail1.object-frontier.com";
	    String emailID = email;
	    
	    TrippleDes tdes = null;
		try {
			tdes = new TrippleDes();
		} catch (Exception e) {
			e.printStackTrace();
		}
	    String password = tdes.decrypt(user.getPwd().getBytes());
	    
	    System.out.println(password);
	    Properties props = System.getProperties();

	    props.put("mail.smtp.host", smtpHostServer);

	    Session session = Session.getInstance(props, null);
	    
	    EmailNotification.sendEmail(session, emailID,"Logging Info", "Your forgot password is "+password+". Please remember this password.");
		
	
		return "Successfull";
	}

}

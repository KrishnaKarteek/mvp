package com.ofs.mvp.dao;

import java.util.List;

import com.ofs.mvp.model.Rate_Cutter;

public interface RateCutterDao {
	
	public List<Rate_Cutter> getRateDetails();

}

package com.ofs.mvp.dao;

import com.ofs.mvp.model.Bill_Details;
import com.ofs.mvp.util.HibernateUtil;

public class BillDetailsDaoImpl implements BillDetailsDao{
	
	HibernateUtil hibernateUtil = new HibernateUtil();
	
	@Override
	public Bill_Details findBillDetailsByServiceNo(int service_no, String month, String year) {
		
		hibernateUtil.openCurrentSession();
		
		Bill_Details bill_details =(Bill_Details) hibernateUtil.getCurrentSession().createQuery("from Bill_Details where year='"+year+"' and month='"+month+"' and service_no="+service_no).uniqueResult();
		
		hibernateUtil.closeCurrentSession();
		
		return bill_details;
	}
	
	@Override
	public Bill_Details getPaymentDetailsUpdate(int service_no, String month, String year) {
		
		String yes = "yes";
		
		hibernateUtil.openCurrentSessionwithTransaction();
		
		
		hibernateUtil.getCurrentSession().createQuery("UPDATE Bill_Details SET pay ='"+yes+"'  where year='"+year+"' and month='"+month+"' and service_no="+service_no).executeUpdate();
		
		hibernateUtil.currentTransaction.commit();
		
		hibernateUtil.closeCurrentSessionwithTransaction();
		
		hibernateUtil.openCurrentSession();
		
		Bill_Details bill_details =(Bill_Details) hibernateUtil.getCurrentSession().createQuery("from Bill_Details where year='"+year+"' and month= '"+month+"' and service_no="+service_no).uniqueResult();
		
		hibernateUtil.closeCurrentSession();
		
		return bill_details;
	}

	
	@Override
	public Bill_Details getPaymentDetails(int bill_id) {
		
		hibernateUtil.openCurrentSession();
		
		Bill_Details bill_details = (Bill_Details) hibernateUtil.getCurrentSession().createQuery("from Bill_Details where bill_id="+bill_id).uniqueResult();
		
		hibernateUtil.closeCurrentSession();
		
		return bill_details;
	}
	
	

}

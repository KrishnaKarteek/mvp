package com.ofs.mvp.dao;

import java.util.Properties;

import javax.mail.Session;

import com.ofs.email_notification.EmailNotification;

public class EmailNotificationDaoImpl implements EmailNotificationDao{
	
	@Override
	public void getEmailNotification(String email) {
		
	  
		
	    String smtpHostServer = "mail1.object-frontier.com";
	    String emailID = email;
	    
	    Properties props = System.getProperties();

	    props.put("mail.smtp.host", smtpHostServer);

	    Session session = Session.getInstance(props, null);
	    
	    EmailNotification.sendEmail(session, emailID, "Logging Info", "You are successfully logged into your account");
		
	}
	

}

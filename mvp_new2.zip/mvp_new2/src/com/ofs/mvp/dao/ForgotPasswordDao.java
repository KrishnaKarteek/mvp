package com.ofs.mvp.dao;

public interface ForgotPasswordDao {
	
	public String getPassword(String email);

}

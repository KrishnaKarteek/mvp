package com.ofs.mvp.service;

import com.ofs.mvp.model.Feedback;

public interface FeedbackService {

	public String saveFeedback(Feedback feedback);
	
}

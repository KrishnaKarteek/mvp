package com.ofs.mvp.service;

import java.util.List;

import com.ofs.mvp.dao.RateCutterDao;
import com.ofs.mvp.dao.RateCutterDaoImpl;
import com.ofs.mvp.model.Rate_Cutter;

public class RateCutterServiceImpl implements RateCutterService {
	
	RateCutterDao rateCutterDao = new RateCutterDaoImpl();
	
	@Override
	public List<Rate_Cutter> getRateDetails() {
		
		return rateCutterDao.getRateDetails( );
	}

	

}

package com.ofs.mvp.service;

import java.util.List;

import javax.mail.internet.MimeMessage;

import com.ofs.email_notification.EmailNotification;
import com.ofs.mvp.model.Bill_Details;
import com.ofs.mvp.model.Feedback;
import com.ofs.mvp.model.Payment;
import com.ofs.mvp.model.Rate_Cutter;
import com.ofs.mvp.model.User;

public interface UserService {
	
	public User findUserByEmail(String email);
	public String addUser(User user);
	
	
	
	
	/*public String addPayment(Payment payment);*/
	
	
	public String updateUser( String first_name, String last_name, String usr_name, String occupation, String marital_status, long phone, String adress, String email, int service_no );
	
	
}

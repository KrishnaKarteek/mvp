package com.ofs.mvp.service;

import com.ofs.mvp.dao.FeedbackDao;
import com.ofs.mvp.dao.FeedbackDaoImpl;
import com.ofs.mvp.model.Feedback;

public class FeedbackServiceImpl implements FeedbackService {
	
	FeedbackDao feedbackDao = new FeedbackDaoImpl();
	
	@Override
	public String saveFeedback(Feedback feedback) {
		
		return feedbackDao.saveFeedback( feedback );
	}

}

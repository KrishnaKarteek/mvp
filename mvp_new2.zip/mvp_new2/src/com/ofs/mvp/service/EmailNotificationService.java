package com.ofs.mvp.service;

public interface EmailNotificationService {
	
	public void getEmailNotification(String email);

}

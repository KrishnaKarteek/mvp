package com.ofs.mvp.service;

import java.util.List;

import com.ofs.mvp.dao.BillHistoryDao;
import com.ofs.mvp.dao.BillHistoryDaoImpl;
import com.ofs.mvp.model.Bill_Details;

public class BillHistoryServiceImpl implements BillHistoryService {
	
	BillHistoryDao billHistoryDao = new BillHistoryDaoImpl();
	
	@Override
	public List<Bill_Details> getBillHistory(int service_no) {
		
		return billHistoryDao.getBillHistory( service_no);
	}


}

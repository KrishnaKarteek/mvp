package com.ofs.mvp.service;

import com.ofs.mvp.dao.BillDetailsDao;
import com.ofs.mvp.dao.BillDetailsDaoImpl;
import com.ofs.mvp.model.Bill_Details;

public class BillDetailsServiceImpl implements BillDetailsService {
	
	BillDetailsDao billDetailsDao = new BillDetailsDaoImpl(); 

	@Override
	public Bill_Details findBillDetailsByServiceNo(int service_no, String month, String year) {
		
		return billDetailsDao.findBillDetailsByServiceNo( service_no, month, year );
	}
	
	@Override
	public Bill_Details getPaymentDetailsUpdate(int service_no, String month, String year) {
		
		return billDetailsDao.getPaymentDetailsUpdate( service_no, month, year );
	}

	
	@Override
	public Bill_Details getPaymentDetails(int bill_id) {
		
		return billDetailsDao.getPaymentDetails( bill_id );
	}

}

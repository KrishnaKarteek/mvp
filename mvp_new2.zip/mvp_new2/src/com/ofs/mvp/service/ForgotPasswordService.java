package com.ofs.mvp.service;

public interface ForgotPasswordService {
	
	public String getPassword(String email);

}

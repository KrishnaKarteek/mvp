package com.ofs.mvp.service;

import com.ofs.mvp.dao.ForgotPasswordDao;
import com.ofs.mvp.dao.ForgotPasswordDaoImpl;

public class ForgotPasswordServiceImpl implements ForgotPasswordService {
	
	ForgotPasswordDao forgotPasswordDao = new ForgotPasswordDaoImpl();
	
	@Override
	public String getPassword(String email) {
		
		return forgotPasswordDao.getPassword(email );
	}

}

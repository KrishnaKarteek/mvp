package com.ofs.mvp.service;

import com.ofs.mvp.dao.EmailNotificationDao;
import com.ofs.mvp.dao.EmailNotificationDaoImpl;

public class EmailNotificationServiceImpl implements EmailNotificationService{
	
	EmailNotificationDao emailNotificationDao = new EmailNotificationDaoImpl();
	
	@Override
	public void getEmailNotification(String email) {
		
		emailNotificationDao.getEmailNotification(email );
	}

}

package com.ofs.mvp.service;

import java.util.List;

import com.ofs.mvp.model.Bill_Details;

public interface BillHistoryService {
	
	public List<Bill_Details> getBillHistory(int service_no);

}

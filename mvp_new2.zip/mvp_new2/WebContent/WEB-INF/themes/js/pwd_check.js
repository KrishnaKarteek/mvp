/**
 * 
 */

var check = function() {
	 document.getElementById('register_btn').disabled = false;
  if (document.getElementById('password').value == document.getElementById('confirm_pwd').value) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'matching';
    
  } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'not matching';
    document.getElementById('register_btn').disabled = true;
  }
}
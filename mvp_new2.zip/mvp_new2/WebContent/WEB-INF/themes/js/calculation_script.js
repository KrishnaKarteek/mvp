var calculate = function(){
	var power_input = $('#power_input').val();
	
	var price;
	
	if(power_input >= 1){
		if(power_input <= 100){
			price = power_input * 0;
		}
		else if(power_input <= 200){
			var power_remaining = power_input - 100;
			price = power_remaining * 1.5;
		}
		else if(power_input <= 500){
			var power_remaining = power_input - 200;
			price = power_remaining * 3 + 200;
		}
		else if(power_input <= 9999999){
			var power_remaining = power_input - 500;
			price = power_remaining * 6.6 + 350 + 1380;
		}
	}
	
	$('.calculation_result').css('display', 'block');
	$('#calculation_result').text(price);
}
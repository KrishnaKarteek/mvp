angular.module('app_module')
.controller('app_ctrl', [ '$scope', 
						 '$state',
						 '$http',
						 'toastr', '$window', function( $scope,
								 			$state,
								 			$http , 
								 			toastr, $window
								   		  ){
	
			var init = function(){		
				$state.go('main.home');
			}
		
			// SignUp
			$scope.register = function( first_name ,last_name, user_name ,mobile_number ,marital_status, occupation, adress, email, password) {
				var url = "http://localhost:9999/mvp_new2/user/add?first_name="+first_name+"&last_name="+last_name+"&usr_name="+user_name+"&occupation="+occupation+"&marital_status="+marital_status+"&phone="+mobile_number+"&adress="+adress+"&email="+email+"&pwd="+password;           
				$http({
					method: 'POST',
					url: url
				}).then(function successCallback(response) {
					if(response.status ==200){
						$state.go('home');
						toastr.success("Your registration is successful");
					}
				});
			};
			
			// Login function
			$scope.login=function(email,pwd) {	
				var url = "http://localhost:9999/mvp_new2/user/auth?email="+email+"&pwd="+pwd;
				$http({
					method: 'GET',
					url: url
				}).then(function successCallback(response) {
						if(response.status == 200){
							var url = "http://localhost:9999/mvp_new2/email_notification/get_email_notification?email="+email;
							$http({
								method: 'POST',
								url: url
								})
							$window.sessionStorage.setItem('user', JSON.stringify(response.data));
							$scope.user_details = JSON.parse($window.sessionStorage.getItem('user'));
							$state.go('user');
						} else {
							alert('Incorrect Password');
							$scope.login_bool = true;
							$scope.registration_bool = true;
							$state.go('home');
						}
					});
			}
			$scope.user_details = JSON.parse($window.sessionStorage.getItem('user'));
			
			$scope.bill_details_bool = true;
			
			// Bill Details
			$scope.getBillDetails = function(service_no)	{	
				$scope.date = new Date();
				$scope.month = $scope.date.getMonth();
				$scope.year = $scope.date.getFullYear();
				var url = "http://localhost:9999/mvp_new2/bill_details/get_bill_details?service_no="+service_no+"&month="+$scope.month+"&year="+$scope.year;
				$http({
					method: 'GET',
					url: url
				}).then(function successCallback(response) {
						if(response.status == 200){
							this.Status = '';
							if(response.data.pay == "yes"){
								$scope.pay_btn_bool = false;
								$scope.bill_id_bool = true;
							} else{
								$scope.pay_btn_bool = true;
								$scope.pay_btn_bool = false;
							}
							$window.sessionStorage.setItem('billDetails', JSON.stringify(response.data));
							$scope.bill_details = JSON.parse($window.sessionStorage.getItem('billDetails'));
							$state.go('user.bill_details');
							
						} else {
							$scope.Status = 'Sorry! Your bill is not generated for this month.';
							$scope.bill_details_bool = false;
							$state.go('user.bill_details');
						}
				});
			}
			$scope.bill_details = JSON.parse($window.sessionStorage.getItem('billDetails'));
			
			
			// Bill Details By Month
			$scope.billDetailsByMonth = function(service_no, month, year)	{		
				var url = "http://localhost:9999/mvp_new2/bill_details/get_bill_details?service_no="+service_no+"&month="+month+"&year="+year;
				$http({
					method: 'GET',
					url: url
				}).then(function successCallback(response) {
						if(response.status == 200){
							$scope.Status = '';
							$scope.bill_details_bool = true;
							if(response.data.pay == "yes"){
								$scope.pay_btn_bool = false;
								$scope.bill_id_bool = true;
							} else{
								$scope.pay_btn_bool = true;
								$scope.bill_id_bool = false;
							}
							$state.go('user.bill_details');
							$window.sessionStorage.setItem('billDetails', JSON.stringify(response.data));
							$scope.bill_details = JSON.parse($window.sessionStorage.getItem('billDetails'));
						} else {
							$scope.Status = 'Sorry! Your bill is not generated for this month.';
							$scope.bill_details_bool = false;
							$state.go('user.bill_details');
						}
					});	
			}
			$scope.bill_details = JSON.parse($window.sessionStorage.getItem('billDetails'));
			
			
			// Bill History
			$scope.getBillHistory = function(service_no){
				var url = "http://localhost:9999/mvp_new2/bill_history/get_bill_history?service_no="+service_no;
				$http({
					method: 'GET',
					url: url
				}).then(function successCallback(response) {
					if(response.status == 200){
						$window.sessionStorage.setItem('billHistory', JSON.stringify(response.data));
						$scope.bill_history = JSON.parse($window.sessionStorage.getItem('billHistory'));
						$state.go('user.bill_history');
					}
				});
			}	
			$scope.bill_history = JSON.parse($window.sessionStorage.getItem('billHistory'));
			
			
			// Bill Payment
			$scope.billPayment = function(service_no, month, year){	
				var url = "http://localhost:9999/mvp_new2/bill_details/bill_payment?service_no="+service_no+"&month="+month+"&year="+year;
				$http({
					method: 'GET',
					url: url
				}).then(function successCallback(response) {
						if(response.status == 200){
							toastr.success("Your payment is successful");
							if(response.data.pay == "yes"){
								$scope.bill_details = response.data;
								$('bill_payment_btn').css('display', 'none');
							}
						} 
				});
				$state.go('user.bill_payment');
			}
			
			$scope.pay = function(){
				$state.go('user.pay');
			}
			
			$scope.viewBillDetails = function(bill_id){
				var url = "http://localhost:9999/mvp_new2/bill_details/payment_details?bill_id="+bill_id;
				$http({
					method: 'GET',
					url: url
				}).then(function successCallback(response) {
						if(response.status == 200){
							$window.sessionStorage.setItem('paymentDetails', JSON.stringify(response.data));
							$scope.payment_details = JSON.parse($window.sessionStorage.getItem('paymentDetails'));
							$state.go('user.bill_payment.payment_details');	
							$('bill_payment_btn').css('display', 'none');
						} 
					});
			}
			$scope.payment_details = JSON.parse($window.sessionStorage.getItem('paymentDetails'));
			
			
			// Account Summary
			$scope.accountSummary = function(){
				var url = "http://localhost:9999/mvp_new2/rate_cutter/get_rate_cutter";
				$http({
					method: 'GET',
					url: url
				}).then(function successCallback(response) {	
						if(response.status == 200){
							$window.sessionStorage.setItem('rateDetails', JSON.stringify(response.data));
							$scope.rate_details = JSON.parse($window.sessionStorage.getItem('rateDetails'));
							$state.go('user.account_summary');
						} else {
						}
					});
				}
			$scope.rate_details = JSON.parse($window.sessionStorage.getItem('rateDetails'));
			
			
			
			// Edit Profile
			$scope.editProfile = function(){
				$state.go('user.edit_profile');
			}
			
			$scope.updateProfile = function(user_details){
				var url = "http://localhost:9999/mvp_new2/user/update?first_name="+user_details.first_name+"&last_name="+user_details.last_name+"&usr_name="+user_details.usr_name+"&occupation="+user_details.occupation+"&marital_status="+user_details.marital_status+"&phone="+user_details.phone+"&adress="+user_details.adress+"&email="+user_details.email+"&service_no="+user_details.service_no;           
				$http({
					method: 'POST',
					url: url
				}).then(function successCallback(response) {
					if(response.status == 200 ){
						toastr.success("Your updation is successful");
						$state.go('user');
					}
				});	
			}
			
			// Feed Back
			$scope.feedback = function(){	
				$state.go('user.feedback');
			}
			
			$scope.saveFeedback = function( feedback_content, service_no ){	
				var url = "http://localhost:9999/mvp_new2/feedback/give_feedback?feedback_content="+feedback_content+"&service_no="+service_no;           
				$http({
					method: 'POST',
					url: url
				}).then(function successCallback(response) {
						if(response.status ==200){
							toastr.success("Your feedback is posted");
							$state.go('user.feedback_success');
						}			
					})
			}
			
			// Logout
			$scope.logout = function(){
					$state.go('main.home');
					$window.sessionStorage.clear();
					$window.location.reload();
				}	
			
			
			$scope.getPwd = function( email ){	
				var url = "http://localhost:9999/mvp_new2/forgot_pwd/get_forgot_pwd?email="+email;           
				$http({
					method: 'GET',
					url: url
				}).then(function successCallback(response) {
						if(response.status ==200){
							$state.go('home');
							toastr.success("Your password is sent to your mail");
						}			
					})
			}
			
			init();
			
}]);

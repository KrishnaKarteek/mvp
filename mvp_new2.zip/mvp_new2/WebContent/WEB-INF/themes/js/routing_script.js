angular.module('app_module',['ui.router', 'toastr'])

.config(function($stateProvider, $urlRouterProvider){

  //$urlRouterProvider.otherwise("/home");

      $stateProvider
          
		  .state('main', {
		      url: '/main',
		      templateUrl: 'views/main.html'
		     
		  })
          .state('main.home', {
              url: '/home',
              templateUrl: 'views/home.html'
             
          })
		  .state('main.registration', {
              url: '/registration',
              templateUrl: 'views/registration.html'
             
          })
		  .state('main.about_us', {
              url: '/about_us',
              templateUrl: 'views/about_us.html'
             
          })
		  .state('main.faq', {
              url: '/faq',
              templateUrl: 'views/faq.html'
             
          })
		  .state('main.bill_calculator', {
              url: '/bill_calculator',
              templateUrl: 'views/bill_calculator.html'
             
          })
		  .state('main.contact_us', {
              url: '/contact_us',
              templateUrl: 'views/contact_us.html'
             
          })
		   .state('main.latest_news', {
              url: '/latest_news',
              templateUrl: 'views/latest_news.html'
             
          })
		  .state('main.terms_and_conditions', {
              url: '/terms_and_conditions',
              templateUrl: 'views/terms_and_conditions.html'
             
          })
		   .state('user', {
              url: '/user',
              templateUrl: 'views/user.html'
		  })
		   .state('user.user_details', {
              url: '/user_details',
              templateUrl: 'views/user_details.html'
             
		  })
		   .state('user.bill_details', {
              url: '/bill_details',
              templateUrl: 'views/bill_details.html'
           
             
		  }) 
		   .state('user.bill_payment', {
              url: '/bill_payment',
              templateUrl: 'views/bill_payment.html'
		  }) 
		   .state('user.bill_history', {
              url: '/bill_history',
              templateUrl: 'views/bill_history.html'
           
		  }) 
		  .state('user.bill_payment.payment_details', {
              url: '/payment_details',
              templateUrl: 'views/payment_details.html'
		  })
		  .state('user.pay', {
              url: '/bank_details',
              templateUrl: 'views/pay.html'
		  })
		  .state('user.account_summary', {
              url: '/account_summary',
              templateUrl: 'views/account_summary.html'
		  })
		   .state('user.edit_profile', {
              url: '/edit_profile',
              templateUrl: 'views/edit_profile.html'
		  })
		   .state('user.feedback', {
              url: '/feedback',
              templateUrl: 'views/feedback.html'
		  })
		   .state('user.feedback_success', {
              url: '/feedback',
              templateUrl: 'views/feedback_success.html'
		  })
		   .state('forgot_pwd', {
              url: '/forgot_password',
              templateUrl: 'views/forgot_pwd.html'
		  })
		   .state('user.bill_details_by_month', {
              url: '/bill_details_by_month',
              templateUrl: 'views/bill_details_by_month.html'
		  });
		  
		  
	});